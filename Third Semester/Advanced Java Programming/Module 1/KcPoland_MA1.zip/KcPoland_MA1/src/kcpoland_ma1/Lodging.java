package kcpoland_ma1;


public class Lodging {
    //Member Variables//
    //All Lodging objects have a Name, Address, Phone Number, Description of Lodging, Rating, Base Price per Night, and a Free Breakfast flag.
    String name;
    String address;
    String phoneNumber;
    String description;
    float rating;
    float basePricePerNight;
    boolean hasFreeBreakfast;
    
    
    //Constructors//
    
    //Default Constructor
    Lodging() {
        name = "Lodging Name";
        phoneNumber = "000-000-0000";
        address = "Lodging Address";
        description = "Lodging Description";
        rating = 0.0f;
        basePricePerNight = 0.00f;
        hasFreeBreakfast = false;
    }
    
    //Overloaded Constructor
    Lodging(String name, String address, String phoneNumber, String description, float rating, float basePricePerNight, boolean hasFreeBreakfast) {
        this.name = name;
        this.address = address;
        this.phoneNumber = phoneNumber;
        this.description = description;
        this.rating = rating;
        this.basePricePerNight = basePricePerNight;
        this.hasFreeBreakfast = hasFreeBreakfast;
    }
    
    
    //String Display Method//
    @Override
    public String toString() {
        return ("\nName: " + name + "\nAddress: " + address + "\nPhone Number: " + phoneNumber + "\nDescription: " + description + "\nRating: " + rating + 
                "\nBase Price Per Night: $" + String.format("%.2f", basePricePerNight) + "\nFree Breakfast: " + hasFreeBreakfast);
    }
}