package kcpoland_ma1;


public class Hotel extends Lodging {
    //Member Variables//
    //All Hotels have records of current Vacancies, amount of Smoking Rooms, Parking Fees, Valet Parking service flag, Bar amenity flag, and Pool amenity flag.
    int vacancies;
    int smokingRooms;
    float parkingFee;
    boolean valetParking;
    boolean bar;
    boolean pool;
    
    
    //Constructors//
    
    //Default Constructor
    Hotel() {
        vacancies = 0;
        smokingRooms = 0;
        parkingFee = 0.00f;
        valetParking = false;
        bar = false;
        pool = false;
    }
    
    //Overloaded Constructor
    Hotel(String name, String address, String phoneNumber, String description, float rating, float basePricePerNight, boolean hasFreeBreakfast, 
            int vacancies, int smokingRooms, float parkingFee, boolean valetParking, boolean bar, boolean pool) {
        super(name, address, phoneNumber, description, rating, basePricePerNight, hasFreeBreakfast);
        this.vacancies = vacancies;
        this.smokingRooms = smokingRooms;
        this.parkingFee = parkingFee;
        this.valetParking = valetParking;
        this.bar = bar;
        this.pool = pool;
    }
    
    
    //String Display Method//
    @Override
    public String toString() {
        String superString = super.toString();
        return (superString + "\nHotel Vacancies: " + vacancies + "\nHotel Smoking Rooms: " + smokingRooms + "\nHotel Parking Fee: $" + String.format("%.2f", parkingFee) + "\nValet Parking: " + valetParking + "\nHotel Bar: " + bar + "\nHotel Pool: " + pool);
    }
}
